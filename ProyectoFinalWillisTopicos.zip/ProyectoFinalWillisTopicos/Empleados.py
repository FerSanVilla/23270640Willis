from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaEmpleados(VentanaBase):
    def __init__(self, siguiente_ventana=None, id_empleado=None):
        super().__init__("Registro de Empleados - Abarrotes Wallis", siguiente_ventana)
        self.id_empleado = id_empleado

        campos = [
            ("id_empleado", "ID Empleado"),
            ("nombre",      "Nombre"),
            ("puesto",      "Puesto"),
            ("num_celular", "Número Celular")
        ]

        # Crear entradas usando .grid()
        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            entry = Entry(self.frame, bg="paleturquoise")
            entry.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = entry

        # Si venimos a editar, cargamos los datos
        if self.id_empleado:
            self._cargar_empleado()

    def _cargar_empleado(self):
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute(
                "SELECT nombre, puesto, num_celular FROM empleados WHERE id_empleado = %s",
                (self.id_empleado,)
            )
            fila = cur.fetchone()
            conn.close()

            if fila is None:
                messagebox.showinfo("Información", "No se encontró el empleado.")
                return

            
            self.entradas["nombre"].insert(0, fila[0])
            self.entradas["puesto"].insert(0, fila[1])
            self.entradas["num_celular"].insert(0, fila[2])

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar empleado:\n{e}")

    def guardar_y_continuar(self):
        id_emp   = self.entradas["id_empleado"].get().strip()
        nombre   = self.entradas["nombre"].get().strip()
        puesto   = self.entradas["puesto"].get().strip()
        celular  = self.entradas["num_celular"].get().strip()

        if not id_emp or not nombre:
            messagebox.showerror("Error", "ID Empleado y Nombre son obligatorios")
            return

        try:
            conn = conectar()
            cur  = conn.cursor()

            if self.id_empleado:
                # Modo edición
                cur.execute("""
                    UPDATE empleados
                    SET nombre = %s,
                        puesto = %s,
                        num_celular = %s
                    WHERE id_empleado = %s
                """, (nombre, puesto, celular, self.id_empleado))
                msg = "Empleado actualizado correctamente."
            else:
                # Modo nuevo
                cur.execute("""
                    INSERT INTO empleados (id_empleado, nombre, puesto, num_celular)
                    VALUES (%s, %s, %s, %s)
                """, (id_emp, nombre, puesto, celular))
                msg = "Empleado registrado correctamente."

            conn.commit()
            conn.close()
            messagebox.showinfo("Éxito", msg)
            self.abrir_siguiente_ventana()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar empleado:\n{e}")
