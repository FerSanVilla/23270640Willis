import mysql.connector
from mysql.connector import Error

def conectar():
    try:
        conn = mysql.connector.connect(
            host='localhost',
            user='root',  # o el usuario que usas
            password='Afvb12122005',  # tu contraseña real
            database='dbwillis',
            auth_plugin='mysql_native_password'  # esto evita errores en MySQL 8+
        )
        return conn
    except Error as e:
        print(f"Error al conectar a MySQL: {e}")
        return None

conectar()