from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaProveedores(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Gestión de Proveedores - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("id_proveedor", "ID Proveedor"),
            ("nombre", "Nombre"),
            ("num_celular", "Número Celular"),
            ("contacto", "Contacto")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            ent = Entry(self.frame, bg="lightgreen")
            ent.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = ent

    def guardar_y_continuar(self):
        id_proveedor = self.entradas["id_proveedor"].get().strip()
        nombre = self.entradas["nombre"].get().strip()
        num_celular = self.entradas["num_celular"].get().strip()
        contacto = self.entradas["contacto"].get().strip()

        if not id_proveedor or not nombre:
            messagebox.showerror("Error", "ID y Nombre son obligatorios")
            return

        try:
            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute("""
                INSERT INTO Proveedores (id_proveedor, nombre, num_celular, contacto)
                VALUES (%s, %s, %s, %s)
            """, (id_proveedor, nombre, num_celular, contacto))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Proveedor guardado correctamente")
            self.abrir_siguiente_ventana()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el proveedor:\n{e}")
