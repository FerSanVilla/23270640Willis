import sqlite3

def crear_base_de_datos():
    conexion = sqlite3.connect("willis.db")
    cursor = conexion.cursor()

    # Categorias
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Categorias (
            id_categoria INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT,
            descripcion TEXT
        )
    """)

    # Proveedores
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Proveedores (
            id_proveedor TEXT PRIMARY KEY,
            nombre TEXT,
            num_celular TEXT,
            contacto TEXT
        )
    """)

    # Productos
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Productos (
            codigo TEXT PRIMARY KEY,
            nombre TEXT,
            precio REAL,
            costo REAL,
            existencias INTEGER,
            id_categoria TEXT,
            id_proveedor TEXT,
            id_unidad TEXT,
            fecha_vencimiento TEXT
        )
    """)

    # compras (en minúsculas, como en tu código)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS compras (
            id_compra TEXT PRIMARY KEY,
            fecha TEXT,
            total REAL,
            id_proveedor TEXT
        )
    """)

    # Empleados
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Empleados (
            id_empleado TEXT PRIMARY KEY,
            nombre TEXT,
            puesto TEXT,
            num_celular TEXT
        )
    """)

    # Clientes
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Clientes (
            id_cliente TEXT PRIMARY KEY,
            nombre TEXT,
            direccion TEXT,
            num_celular TEXT
        )
    """)

    # Ventas
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Ventas (
            id_venta TEXT PRIMARY KEY,
            fecha TEXT,
            importe REAL,
            id_cliente TEXT,
            id_empleado TEXT
        )
    """)

    conexion.commit()
    conexion.close()
    print("✅ Base de datos 'willis.db' creada correctamente con nombres exactos.")

if __name__ == "__main__":
    crear_base_de_datos()
