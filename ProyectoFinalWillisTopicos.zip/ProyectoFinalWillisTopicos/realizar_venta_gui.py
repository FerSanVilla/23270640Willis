import tkinter as tk
from tkinter import messagebox, ttk
from conexion_bd import conectar  # Asegúrate que esta función está bien definida para conectar a tu BD
from datetime import datetime

class VentanaVenta:
    def __init__(self, root):
        self.root = root
        self.root.title("Módulo de Ventas - Abarrotes Wallis")
        self.carrito = []  # Lista de tuplas: (codigo, nombre, cantidad, precio, total)
        self.crear_interfaz()

    def crear_interfaz(self):
        tk.Label(self.root, text="ID Cliente:").grid(row=0, column=0)
        self.entry_cliente = tk.Entry(self.root)
        self.entry_cliente.grid(row=0, column=1)
        tk.Button(self.root, text="Buscar", command=self.buscar_cliente).grid(row=0, column=2)
        self.label_datos_cliente = tk.Label(self.root, text="Cliente: General")
        self.label_datos_cliente.grid(row=1, column=0, columnspan=3)

        tk.Label(self.root, text="Código producto:").grid(row=2, column=0)
        self.entry_codigo = tk.Entry(self.root)
        self.entry_codigo.grid(row=2, column=1)

        tk.Label(self.root, text="Cantidad:").grid(row=3, column=0)
        self.entry_cantidad = tk.Entry(self.root)
        self.entry_cantidad.grid(row=3, column=1)

        tk.Button(self.root, text="Agregar", command=self.agregar_producto).grid(row=4, column=1)

        self.tree = ttk.Treeview(self.root, columns=("codigo", "nombre", "cantidad", "precio", "total"), show="headings")
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col.capitalize())
        self.tree.grid(row=5, column=0, columnspan=3)

        tk.Button(self.root, text="Eliminar seleccionado", command=self.eliminar_producto).grid(row=6, column=0)
        tk.Button(self.root, text="Pagar", command=self.pagar).grid(row=6, column=2)

        # Aquí agregamos una vista para mostrar ventas recientes
        tk.Label(self.root, text="Ventas recientes:").grid(row=7, column=0, columnspan=3)
        self.tree_ventas = ttk.Treeview(self.root, columns=("id_venta", "fecha", "cliente", "total", "metodo_pago"), show="headings")
        for col in self.tree_ventas["columns"]:
            self.tree_ventas.heading(col, text=col.capitalize())
        self.tree_ventas.grid(row=8, column=0, columnspan=3)

        self.cargar_ventas()

    def buscar_cliente(self):
        id_cliente = self.entry_cliente.get().strip()
        if not id_cliente.isdigit():
            self.label_datos_cliente.config(text="Cliente: General")
            return
        id_cliente = int(id_cliente)
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT nombre FROM Clientes WHERE id_cliente = %s", (id_cliente,))
        cliente = cursor.fetchone()
        conexion.close()
        if cliente:
            self.label_datos_cliente.config(text=f"Cliente: {cliente[0]}")
        else:
            self.label_datos_cliente.config(text="Cliente: General")

    def agregar_producto(self):
        codigo = self.entry_codigo.get().strip()
        cantidad_str = self.entry_cantidad.get().strip()
        if not codigo or not cantidad_str.isdigit():
            messagebox.showerror("Error", "Código o cantidad inválida.")
            return
        cantidad = int(cantidad_str)
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT nombre, precio FROM Productos WHERE codigo = %s", (codigo,))
        producto = cursor.fetchone()
        conexion.close()
        if producto:
            nombre, precio = producto
            subtotal = precio * cantidad
            self.carrito.append((codigo, nombre, cantidad, precio, subtotal))
            self.tree.insert("", "end", values=(codigo, nombre, cantidad, precio, subtotal))
        else:
            messagebox.showerror("Error", "Producto no encontrado.")

    def eliminar_producto(self):
        selected = self.tree.selection()
        if selected:
            index = self.tree.index(selected[0])
            self.tree.delete(selected[0])
            del self.carrito[index]

    def pagar(self):
        if not self.carrito:
            messagebox.showwarning("Advertencia", "No hay productos en el carrito.")
            return

        id_cliente_str = self.entry_cliente.get().strip()
        if not id_cliente_str.isdigit():
            id_cliente = 0  # Cliente General con id 0
        else:
            id_cliente = int(id_cliente_str)

        id_empleado = 1  # Cambia por el ID real del empleado en tu base
        metodo_pago = "Efectivo"
        total = sum(item[4] for item in self.carrito)
        fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute(
                "INSERT INTO Ventas (fecha, id_cliente, id_empleado, total, metodo_pago) VALUES (%s, %s, %s, %s, %s)",
                (fecha, id_cliente, id_empleado, total, metodo_pago)
            )
            id_venta = cursor.lastrowid

            for item in self.carrito:
                codigo, _, cantidad, precio, _ = item
                cursor.execute(
                    "INSERT INTO DetalleVentas (id_venta, codigo_producto, cantidad, precio_unitario) VALUES (%s, %s, %s, %s)",
                    (id_venta, codigo, cantidad, precio)
                )

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Venta registrada exitosamente.")
            self.carrito.clear()
            self.tree.delete(*self.tree.get_children())

            self.cargar_ventas()  # Actualiza la lista de ventas al pagar

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo completar la venta:\n{e}")

    def cargar_ventas(self):
        # Limpiar lista actual
        for item in self.tree_ventas.get_children():
            self.tree_ventas.delete(item)

        try:
            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute("""
                SELECT v.id_venta, v.fecha, c.nombre, v.total, v.metodo_pago
                FROM Ventas v
                LEFT JOIN Clientes c ON v.id_cliente = c.id_cliente
                ORDER BY v.id_venta DESC
                LIMIT 10
            """)
            ventas = cursor.fetchall()
            conexion.close()

            for venta in ventas:
                id_venta, fecha, cliente, total, metodo_pago = venta
                cliente = cliente if cliente else "General"
                self.tree_ventas.insert("", "end", values=(id_venta, fecha, cliente, total, metodo_pago))

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar las ventas:\n{e}")


if __name__ == "__main__":
    root = tk.Tk()
    app = VentanaVenta(root)
    root.mainloop()
