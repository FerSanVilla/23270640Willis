from tkinter import Toplevel, Label, Entry, Button, Frame, messagebox, ttk
from conexion_bd import conectar
from base import VentanaBase
from datetime import datetime

class VentanaVentas(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Módulo de Ventas - Abarrotes Wallis", siguiente_ventana)
        self.carrito = []
        self.total = 0

        # Entrada cliente
        self.lbl_id_cliente = Label(self.ventana, text="ID Cliente:")
        self.lbl_id_cliente.grid(row=0, column=0)
        self.entry_id_cliente = Entry(self.ventana)
        self.entry_id_cliente.grid(row=0, column=1)
        self.btn_buscar_cliente = Button(self.ventana, text="Buscar", command=self.buscar_cliente)
        self.btn_buscar_cliente.grid(row=0, column=2)
        self.lbl_datos_cliente = Label(self.ventana, text="Cliente: General")
        self.lbl_datos_cliente.grid(row=1, column=0, columnspan=3)

        # Entrada productos
        self.lbl_codigo = Label(self.ventana, text="Código Producto:")
        self.lbl_codigo.grid(row=2, column=0)
        self.entry_codigo = Entry(self.ventana)
        self.entry_codigo.grid(row=2, column=1)

        self.lbl_cantidad = Label(self.ventana, text="Cantidad:")
        self.lbl_cantidad.grid(row=3, column=0)
        self.entry_cantidad = Entry(self.ventana)
        self.entry_cantidad.grid(row=3, column=1)

        self.btn_agregar = Button(self.ventana, text="Agregar", command=self.agregar_producto)
        self.btn_agregar.grid(row=3, column=2)

        # Tabla productos en carrito
        self.tabla = ttk.Treeview(self.ventana, columns=("codigo", "nombre", "cantidad", "precio", "subtotal"), show="headings")
        self.tabla.heading("codigo", text="Código")
        self.tabla.heading("nombre", text="Nombre")
        self.tabla.heading("cantidad", text="Cantidad")
        self.tabla.heading("precio", text="Precio")
        self.tabla.heading("subtotal", text="Subtotal")
        self.tabla.grid(row=4, column=0, columnspan=3)

        self.btn_eliminar = Button(self.ventana, text="Eliminar seleccionado", command=self.eliminar_producto)
        self.btn_eliminar.grid(row=5, column=0)

        self.lbl_total = Label(self.ventana, text="Total: $0.00")
        self.lbl_total.grid(row=5, column=1)

        self.btn_pagar = Button(self.ventana, text="Pagar", command=self.procesar_venta)
        self.btn_pagar.grid(row=5, column=2)

    def buscar_cliente(self):
        conexion = conectar()
        cursor = conexion.cursor()
        id_cliente = self.entry_id_cliente.get()
        cursor.execute("SELECT nombre FROM Clientes WHERE id_cliente = %s", (id_cliente,))
        cliente = cursor.fetchone()
        if cliente:
            self.lbl_datos_cliente.config(text=f"Cliente: {cliente[0]}")
        else:
            self.lbl_datos_cliente.config(text="Cliente: General")
        conexion.close()

    def agregar_producto(self):
        codigo = self.entry_codigo.get()
        try:
            cantidad = int(self.entry_cantidad.get())
        except ValueError:
            messagebox.showerror("Error", "Cantidad inválida")
            return

        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT nombre, precio FROM Productos WHERE codigo = %s", (codigo,))
        producto = cursor.fetchone()
        conexion.close()

        if producto:
            nombre, precio = producto
            subtotal = cantidad * precio
            self.carrito.append((codigo, nombre, cantidad, precio, subtotal))
            self.tabla.insert("", "end", values=(codigo, nombre, cantidad, precio, subtotal))
            self.total += subtotal
            self.lbl_total.config(text=f"Total: ${self.total:.2f}")
        else:
            messagebox.showerror("Error", "Producto no encontrado")

    def eliminar_producto(self):
        item = self.tabla.selection()
        if item:
            valores = self.tabla.item(item, "values")
            subtotal = float(valores[4])
            self.total -= subtotal
            self.lbl_total.config(text=f"Total: ${self.total:.2f}")
            self.tabla.delete(item)
            self.carrito = [prod for prod in self.carrito if not (prod[0] == valores[0] and str(prod[2]) == str(valores[2]))]

    def procesar_venta(self):
        if not self.carrito:
            messagebox.showerror("Error", "No hay productos en la venta.")
            return

        try:
            conexion = conectar()
            cursor = conexion.cursor()
            fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            id_cliente = self.entry_id_cliente.get()

            cursor.execute("SELECT * FROM Clientes WHERE id_cliente = %s", (id_cliente,))
            if not cursor.fetchone():
                id_cliente = 0  # Cliente general con ID 0

            id_empleado = 1  # ID fijo para pruebas
            metodo_pago = "Efectivo"

            cursor.execute("INSERT INTO Ventas (fecha, id_cliente, id_empleado, total, metodo_pago) VALUES (%s, %s, %s, %s, %s)",
                           (fecha, id_cliente, id_empleado, self.total, metodo_pago))
            id_venta = cursor.lastrowid

            for producto in self.carrito:
                codigo, _, cantidad, precio, _ = producto
                cursor.execute("INSERT INTO DetalleVentas (id_venta, codigo_producto, cantidad, precio_unitario) VALUES (%s, %s, %s, %s)",
                               (id_venta, codigo, cantidad, precio))

            conexion.commit()
            conexion.close()
            messagebox.showinfo("Éxito", "Venta registrada exitosamente.")
            self.ventana.destroy()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo completar la venta:\n{e}")
