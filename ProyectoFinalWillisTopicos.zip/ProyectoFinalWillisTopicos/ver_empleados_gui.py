from tkinter import Label, Listbox, Scrollbar, Button, END, messagebox
from base import VentanaBase
from conexion_bd import conectar
from Empleados import VentanaEmpleados

class VentanaVerEmpleados(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Empleados Registrados - Abarrotes Wallis", siguiente_ventana)
        self.geometry("600x450")

        Label(self, text="Listado de Empleados", font=("Arial", 14, "bold")).pack(pady=10)

        scroll = Scrollbar(self)
        scroll.pack(side="right", fill="y")
        self.lista = Listbox(self, font=("Consolas", 12), yscrollcommand=scroll.set)
        self.lista.pack(padx=20, pady=10, fill="both", expand=True)
        scroll.config(command=self.lista.yview)

        # Botones
        btn_frame = Label(self)
        btn_frame.pack(pady=5)
        Button(btn_frame, text="Refrescar", command=self.cargar_empleados).grid(row=0, column=0, padx=5)
        Button(btn_frame, text="Editar",    command=self._editar).grid(row=0, column=1, padx=5)
        Button(btn_frame, text="Eliminar",  command=self._eliminar).grid(row=0, column=2, padx=5)

        self.cargar_empleados()

    def cargar_empleados(self):
        self.lista.delete(0, END)
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("SELECT id_empleado, nombre, puesto, num_celular FROM empleados")
            self.registros = cur.fetchall()
            conn.close()

            if not self.registros:
                self.lista.insert(END, "No hay empleados registrados.")
                return

            header = f"{'ID':<15}{'Nombre':<25}{'Puesto':<20}{'Celular'}"
            self.lista.insert(END, header)
            self.lista.insert(END, "-"*70)

            for emp in self.registros:
                linea = f"{emp[0]:<15}{emp[1]:<25}{emp[2]:<20}{emp[3]}"
                self.lista.insert(END, linea)

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los datos:\n{e}")

    def _editar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un empleado válido.")
            return
        idx = sel[0] - 2
        id_emp = self.registros[idx][0]
        self.destroy()
        VentanaEmpleados(None, id_empleado=id_emp).mainloop()

    def _eliminar(self):
        sel = self.lista.curselection()
        if not sel or sel[0] < 2:
            messagebox.showwarning("Seleccionar", "Selecciona un empleado válido.")
            return
        idx = sel[0] - 2
        id_emp  = self.registros[idx][0]
        nombre  = self.registros[idx][1]
        if not messagebox.askyesno("Confirmar", f"Eliminar empleado '{nombre}'?"):
            return
        try:
            conn = conectar()
            cur  = conn.cursor()
            cur.execute("DELETE FROM empleados WHERE id_empleado = %s", (id_emp,))
            conn.commit()
            conn.close()
            messagebox.showinfo("Éxito", "Empleado eliminado.")
            self.cargar_empleados()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar:\n{e}")

if __name__ == "__main__":
    VentanaVerEmpleados().mainloop()
