from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaProductos(VentanaBase):
    def __init__(self, siguiente_ventana=None):
        super().__init__("Registro de Productos - Abarrotes Wallis", siguiente_ventana)

        campos = [
            ("codigo", "Código"),
            ("nombre", "Nombre"),
            ("precio", "Precio"),
            ("costo", "Costo"),
            ("existencias", "Existencias"),
            ("id_categoria", "ID Categoría"),
            ("id_proveedor", "ID Proveedor"),
            ("id_unidad", "ID Unidad"),
            ("fecha_vencimiento", "Fecha Vencimiento")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            ent = Entry(self.frame, bg="lightblue")
            ent.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = ent

    def guardar_y_continuar(self):
        try:
            if not self.entradas["codigo"].get() or not self.entradas["nombre"].get():
                messagebox.showerror("Error", "Código y Nombre son obligatorios")
                return

            # Validación de valores numéricos
            precio = self.entradas["precio"].get().strip()
            costo = self.entradas["costo"].get().strip()
            existencias = self.entradas["existencias"].get().strip()

            precio = float(precio) if precio else None
            costo = float(costo) if costo else None
            existencias = int(existencias) if existencias else 0

            conexion = conectar()
            cursor = conexion.cursor()

            cursor.execute("""
                INSERT INTO Productos (codigo, nombre, precio, costo, existencias, id_categoria, id_proveedor, id_unidad, fecha_vencimiento)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                self.entradas["codigo"].get().strip(),
                self.entradas["nombre"].get().strip(),
                precio,
                costo,
                existencias,
                self.entradas["id_categoria"].get().strip(),
                self.entradas["id_proveedor"].get().strip(),
                self.entradas["id_unidad"].get().strip(),
                self.entradas["fecha_vencimiento"].get().strip()
            ))

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", "Producto guardado correctamente")
            self.abrir_siguiente_ventana()

        except ValueError:
            messagebox.showerror("Error", "Los campos numéricos deben tener valores válidos")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el producto:\n{e}")
