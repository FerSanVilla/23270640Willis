from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaCategorias(VentanaBase):
    def __init__(self, siguiente_ventana=None, id_categoria=None):
        super().__init__("Categorías - Abarrotes Wallis", siguiente_ventana)
        self.id_categoria = id_categoria

        Label(self.frame, text="Nombre:").grid(row=0, column=0, padx=10, pady=5)
        self.entradas["nombre"] = Entry(self.frame)
        self.entradas["nombre"].grid(row=0, column=1, padx=10, pady=5)

        Label(self.frame, text="Descripción:").grid(row=1, column=0, padx=10, pady=5)
        self.entradas["descripcion"] = Entry(self.frame)
        self.entradas["descripcion"].grid(row=1, column=1, padx=10, pady=5)

        if self.id_categoria:
            self.cargar_categoria()

    def cargar_categoria(self):
        try:
            conexion = conectar()
            cursor = conexion.cursor()
            cursor.execute("SELECT nombre, descripcion FROM Categorias WHERE id_categoria = %s", (self.id_categoria,))
            categoria = cursor.fetchone()
            conexion.close()

            if categoria:
                self.entradas["nombre"].insert(0, categoria[0])
                self.entradas["descripcion"].insert(0, categoria[1])
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar la categoría:\n{e}")

    def guardar_y_continuar(self):
        nombre = self.entradas["nombre"].get()
        descripcion = self.entradas["descripcion"].get()

        if not nombre:
            messagebox.showerror("Error", "El nombre es obligatorio.")
            return

        try:
            conexion = conectar()
            cursor = conexion.cursor()

            if self.id_categoria:
                cursor.execute("""
                    UPDATE Categorias
                    SET nombre = %s, descripcion = %s
                    WHERE id_categoria = %s
                """, (nombre, descripcion, self.id_categoria))
                mensaje = "Categoría actualizada correctamente."
            else:
                cursor.execute("INSERT INTO Categorias (nombre, descripcion) VALUES (%s, %s)", (nombre, descripcion))
                mensaje = "Categoría guardada correctamente."

            conexion.commit()
            conexion.close()

            messagebox.showinfo("Éxito", mensaje)
            self.abrir_siguiente_ventana()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar:\n{e}")
