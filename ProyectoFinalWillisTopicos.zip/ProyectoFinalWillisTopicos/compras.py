from tkinter import Label, Entry, messagebox
from base import VentanaBase
from conexion_bd import conectar

class VentanaCompras(VentanaBase):
    def __init__(self, siguiente_ventana=None, id_compra=None):
        super().__init__("Registro de Compras - Abarrotes Wallis", siguiente_ventana)
        self.id_compra = id_compra

        campos = [
            ("id_compra", "ID Compra"),
            ("fecha", "Fecha"),
            ("total", "Total")
        ]

        for i, (clave, texto) in enumerate(campos):
            lbl = Label(self.frame, text=texto)
            lbl.grid(row=i, column=0, padx=10, pady=5)
            entry = Entry(self.frame, bg="lightyellow")
            entry.grid(row=i, column=1, padx=10, pady=5)
            self.entradas[clave] = entry

        if self.id_compra:
            self._cargar_compra()

    def _cargar_compra(self):
        try:
            conn = conectar()
            cur = conn.cursor()
            # Traemos solo los campos que usas en la lista campos
            cur.execute("SELECT id_compra, fecha, total FROM compras WHERE id_compra = %s", (self.id_compra,))
            fila = cur.fetchone()
            conn.close()
            if fila:
                # Aquí asignamos a las entradas según la lista campos
                self.entradas["id_compra"].insert(0, fila[0])
                self.entradas["fecha"].insert(0, fila[1])
                self.entradas["total"].insert(0, str(fila[2]))
                # Deshabilitar editar ID compra
                self.entradas["id_compra"].config(state="disabled")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo cargar la compra:\n{e}")

    def guardar_y_continuar(self):
        datos = {k: self.entradas[k].get().strip() for k in self.entradas}

        if not datos["id_compra"] or not datos["fecha"]:
            messagebox.showerror("Error", "ID Compra y Fecha son obligatorios")
            return

        try:
            total_float = float(datos["total"]) if datos["total"] else None
        except ValueError:
            messagebox.showerror("Error", "Total debe ser numérico")
            return

        try:
            conn = conectar()
            cur = conn.cursor()

            if self.id_compra:
                cur.execute("""
                    UPDATE compras
                       SET fecha = %s,
                           total = %s
                     WHERE id_compra = %s
                """, (datos["fecha"], total_float, self.id_compra))
                msg = "Compra actualizada correctamente."
            else:
                cur.execute("""
                    INSERT INTO compras (id_compra, fecha, total)
                    VALUES (%s, %s, %s)
                """, (datos["id_compra"], datos["fecha"], total_float))
                msg = "Compra registrada correctamente."

            conn.commit()
            conn.close()
            messagebox.showinfo("Éxito", msg)
            self.abrir_siguiente_ventana()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar la compra:\n{e}")
