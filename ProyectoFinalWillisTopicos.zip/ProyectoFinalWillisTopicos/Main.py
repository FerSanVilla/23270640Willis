import tkinter as tk
from Categorias import VentanaCategorias
from Proveedores import VentanaProveedores
from Productos import VentanaProductos
from compras import VentanaCompras
from Empleados import VentanaEmpleados
from Clientes import VentanaClientes
from Ventas import VentanaVentas

class VentanaPrincipal(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema Abarrotes Wallis - Menú Principal")
        self.geometry("400x400")

        tk.Label(self, text="Selecciona un módulo", font=("Arial", 14)).pack(pady=10)

        botones = [
            ("Categorías", VentanaCategorias),
            ("Proveedores", VentanaProveedores),
            ("Productos", VentanaProductos),
            ("Compras", VentanaCompras),
            ("Empleados", VentanaEmpleados),
            ("Clientes", VentanaClientes),
            ("Ventas", VentanaVentas),
        ]

        for texto, clase in botones:
            tk.Button(self, text=texto, width=30, command=lambda c=clase: c()).pack(pady=5)

if __name__ == "__main__":
    app = VentanaPrincipal()
    app.mainloop()
