-- Usar la base de datos
USE willisdb;

-- Insertar datos en la tabla Categorias
INSERT INTO Categorias (nombre, descripcion) VALUES
('Electrónicos', 'Productos electrónicos y gadgets'),
('Alimentos', 'Productos alimenticios y comestibles'),
('Hogar', 'Artículos para el hogar'),
('Oficina', 'Artículos de oficina y papelería'),
('Ropa', 'Prendas de vestir y accesorios');

-- Insertar datos en la tabla Proveedores
INSERT INTO Proveedores (id_proveedor, nombre, num_celular, contacto) VALUES
('PROV001', 'Distribuidora Electrónica S.A.', '555-1234', 'Juan Pérez'),
('PROV002', 'Alimentos del Valle', '555-2345', 'María García'),
('PROV003', 'Hogar y Más', '555-3456', 'Roberto Sánchez'),
('PROV004', 'Oficina Total', '555-4567', 'Laura Martínez'),
('PROV005', 'Moda Express', '555-5678', 'Carlos Rodríguez');

-- Insertar datos en la tabla Clientes
INSERT INTO Clientes (id_cliente, nombre, telefono, direccion) VALUES
('CLI001', 'Ana Gómez', '555-6789', 'Calle Principal 123'),
('CLI002', 'Pedro Ramírez', '555-7890', 'Av. Central 456'),
('CLI003', 'Sofía Torres', '555-8901', 'Blvd. Norte 789'),
('CLI004', 'Luis Hernández', '555-9012', 'Calle Sur 234'),
('CLI005', 'Carmen Díaz', '555-0123', 'Av. Este 567');

-- Insertar datos en la tabla Empleados
INSERT INTO Empleados (id_empleado, nombre, puesto, num_celular) VALUES
('EMP001', 'Miguel Vázquez', 'Vendedor', '555-1111'),
('EMP002', 'Isabel López', 'Cajero', '555-2222'),
('EMP003', 'Fernando Castro', 'Gerente', '555-3333'),
('EMP004', 'Lucía Mendoza', 'Almacenista', '555-4444'),
('EMP005', 'Jorge Ortiz', 'Vendedor', '555-5555');

-- Insertar datos en la tabla Productos
-- Nota: Ahora id_categoria es INT y se relaciona con la tabla Categorias
INSERT INTO Productos (codigo, nombre, precio, costo, existencias, id_categoria) VALUES
('PROD001', 'Smartphone XYZ', 499.99, 350.00, 20, 1),
('PROD002', 'Café Premium 500g', 12.99, 8.50, 50, 2),
('PROD003', 'Sartén Antiadherente', 29.99, 18.75, 15, 3),
('PROD004', 'Resma de Papel A4', 5.99, 3.25, 100, 4),
('PROD005', 'Camiseta Algodón', 19.99, 10.50, 30, 5);

-- Insertar datos en la tabla Compras
INSERT INTO Compras (fecha, id_proveedor, total) VALUES
('2025-01-15 10:30:00', 'PROV001', 7000.00),
('2025-01-20 11:45:00', 'PROV002', 425.00),
('2025-02-05 09:15:00', 'PROV003', 281.25),
('2025-02-10 14:20:00', 'PROV004', 325.00),
('2025-02-15 16:30:00', 'PROV005', 315.00);

-- Insertar datos en la tabla DetalleCompras
INSERT INTO DetalleCompras (id_compra, codigo_producto, cantidad, costo_unitario) VALUES
(1, 'PROD001', 20, 350.00),
(2, 'PROD002', 50, 8.50),
(3, 'PROD003', 15, 18.75),
(4, 'PROD004', 100, 3.25),
(5, 'PROD005', 30, 10.50);

-- Insertar datos en la tabla Ventas
INSERT INTO Ventas (fecha, id_cliente, id_empleado, total, metodo_pago) VALUES
('2025-03-01 13:15:00', 'CLI001', 'EMP001', 499.99, 'Tarjeta'),
('2025-03-02 14:30:00', 'CLI002', 'EMP002', 25.98, 'Efectivo'),
('2025-03-03 10:45:00', 'CLI003', 'EMP001', 29.99, 'Tarjeta'),
('2025-03-04 16:20:00', 'CLI004', 'EMP002', 11.98, 'Efectivo'),
('2025-03-05 11:30:00', 'CLI005', 'EMP001', 39.98, 'Transferencia');

-- Insertar datos en la tabla DetalleVentas
INSERT INTO DetalleVentas (id_venta, codigo_producto, cantidad, precio_unitario) VALUES
(1, 'PROD001', 1, 499.99),
(2, 'PROD002', 2, 12.99),
(3, 'PROD003', 1, 29.99),
(4, 'PROD004', 2, 5.99),
(5, 'PROD005', 2, 19.99);
