-- Crear la base de datos y usarla
CREATE DATABASE IF NOT EXISTS dbwillis;
USE dbwillis;

-- Tablas
CREATE TABLE Categorias (
    id_categoria INT PRIMARY KEY,
    nombre VARCHAR(100),
    descripcion TEXT
);

CREATE TABLE Clientes (
    id_cliente INT PRIMARY KEY,
    nombre VARCHAR(100),
    telefono CHAR(10),
    direccion TEXT
);

CREATE TABLE Compras (
    id_compra INT PRIMARY KEY,
    fecha DATE,
    total DECIMAL(10, 2)
);

CREATE TABLE Empleados (
    id_empleado INT PRIMARY KEY,
    nombre VARCHAR(100),
    puesto VARCHAR(100),
    num_celular CHAR(10)
);

CREATE TABLE Productos (
    codigo INT PRIMARY KEY,
    nombre VARCHAR(100),
    precio DECIMAL(10, 2),
    costo DECIMAL(10, 2),
    existencias INT
);

CREATE TABLE Proveedores (
    id_proveedor INT PRIMARY KEY,
    nombre VARCHAR(100),
    num_celular CHAR(10),
    contacto VARCHAR(100)
);

CREATE TABLE Ventas (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE,
    total DECIMAL(10, 2),
    metodo_pago VARCHAR(50),
    id_cliente INT,
    id_empleado INT,
    FOREIGN KEY (id_cliente) REFERENCES Clientes(id_cliente),
    FOREIGN KEY (id_empleado) REFERENCES Empleados(id_empleado)
);

CREATE TABLE DetalleVentas (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_venta INT,
    codigo_producto INT,
    cantidad INT,
    precio_unitario DECIMAL(10, 2),
    FOREIGN KEY (id_venta) REFERENCES Ventas(id_venta),
    FOREIGN KEY (codigo_producto) REFERENCES Productos(codigo)
);

-- Insertar cliente general
INSERT INTO Clientes (id_cliente, nombre, telefono, direccion)
VALUES (0, 'Cliente General', '0000000000', 'Sin dirección')
ON DUPLICATE KEY UPDATE nombre = 'Cliente General';

INSERT INTO Empleados (id_empleado, nombre, puesto, num_celular) 
VALUES ('EMP001', 'Empleado Prueba', 'Cajero', '5550001111');

-- Insertar datos de ejemplo
INSERT INTO Clientes VALUES
(1, 'Ana Pérez', '5551234567', 'Calle Sol #123'),
(2, 'Luis Gómez', '5559876543', 'Av. Luna #456'),
(3, 'María López', '5556789012', 'Calle Estrella #789'),
(4, 'Carlos Ruiz', '5551112233', 'Av. Marte #321'),
(5, 'Lucía Torres', '5553334444', 'Calle Neptuno #101');

INSERT INTO Empleados VALUES
(1, 'Pedro Martínez', 'Cajero', '5556667777'),
(2, 'Andrea Ramírez', 'Vendedor', '5558889999'),
(3, 'Fernando Díaz', 'Encargado', '5551110000'),
(4, 'Sofía Mendoza', 'Bodeguero', '5554442222'),
(5, 'Jorge Herrera', 'Repartidor', '5559998888');

INSERT INTO Categorias VALUES
(1, 'Bebidas', 'Bebidas frías y calientes'),
(2, 'Snacks', 'Botanas y productos para picar'),
(3, 'Limpieza', 'Artículos de limpieza para el hogar'),
(4, 'Lácteos', 'Productos derivados de la leche'),
(5, 'Cuidado Personal', 'Higiene y cuidado personal');

INSERT INTO Productos VALUES
(100, 'Refresco Cola', 18.50, 12.00, 100),
(101, 'Papas Chips', 22.00, 15.00, 50),
(102, 'Detergente', 35.00, 20.00, 30),
(103, 'Yogurt Natural', 12.00, 8.00, 60),
(104, 'Shampoo Herbal', 45.00, 28.00, 40);

INSERT INTO Proveedores VALUES
(1, 'Distribuidora Norte', '5551122334', 'Juan Ramírez'),
(2, 'Proveedor Sur', '5552233445', 'Laura Pérez'),
(3, 'Central Alimentos', '5553344556', 'Héctor Jiménez'),
(4, 'LimpiezaMax', '5554455667', 'Paola Mendoza'),
(5, 'DermoCare', '5555566778', 'Luis Téllez');

INSERT INTO Compras VALUES
(1, '2024-05-01', 1250.50),
(2, '2024-05-02', 890.00),
(3, '2024-05-03', 450.75),
(4, '2024-05-04', 320.90),
(5, '2024-05-05', 1050.00);

-- Ventas (puedes omitir las anteriores si ya estaban insertadas sin cliente y empleado)
-- INSERT INTO Ventas (fecha, total, metodo_pago, id_cliente, id_empleado) VALUES ...

