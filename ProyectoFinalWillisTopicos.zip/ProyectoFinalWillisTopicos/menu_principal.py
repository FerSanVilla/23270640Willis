
import tkinter as tk
from tkinter import ttk
import subprocess
import sys
import os

# Función para ejecutar un archivo Python externo
def ejecutar_archivo(nombre_archivo):
    ruta = os.path.join(os.path.dirname(__file__), nombre_archivo)
    if os.path.exists(ruta):
        subprocess.Popen([sys.executable, ruta])
    else:
        print(f"No se encontró el archivo: {ruta}")

# Crear ventana principal
ventana = tk.Tk()
ventana.title("Panel Principal – Tablas del Sistema")
ventana.geometry("400x600")
ventana.configure(bg="#f0f0f0")

# Título
titulo = tk.Label(ventana, text="Panel de Tablas", font=("Arial", 18, "bold"), bg="#f0f0f0")
titulo.pack(pady=20)

# Lista de botones y archivos correspondientes
opciones = [
    ("Ver Clientes", "ver_clientes_gui.py"),
    ("Ver Empleados", "ver_empleados_gui.py"),
    ("Ver Proveedores", "ver_proveedores_gui.py"),
    ("Ver Productos", "ver_productos_gui.py"),
    ("Ver Categorías", "ver_categorias_gui.py"),
    ("Ver Ventas", "ver_ventas_gui.py"),
    ("Ver Compras", "ver_compras_gui.py"),
]

# Crear botones dinámicamente
for texto, archivo in opciones:
    btn = tk.Button(ventana, text=texto, command=lambda a=archivo: ejecutar_archivo(a),
                    width=30, height=2, bg="#4CAF50", fg="white", font=("Arial", 12, "bold"))
    btn.pack(pady=8)

# Ejecutar ventana
ventana.mainloop()
